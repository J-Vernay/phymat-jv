var searchData=
[
  ['k1_91',['k1',['../classDragGenerator.html#a8b4c2797de80275546db6596f4c4c2a3',1,'DragGenerator']]],
  ['k2_92',['k2',['../classDragGenerator.html#a9ae4aa4da5bae1bd8d19b4925f6d244b',1,'DragGenerator']]]
];
