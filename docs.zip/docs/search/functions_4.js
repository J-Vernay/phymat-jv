var searchData=
[
  ['end_5fframe_273',['end_frame',['../classWindow.html#a43f15a9745432c5c966ab8614b93a29c',1,'Window']]],
  ['end_5fui_274',['end_ui',['../classWindow.html#af36fc0cbd614b0d309756d268d36afa6',1,'Window']]]
];
