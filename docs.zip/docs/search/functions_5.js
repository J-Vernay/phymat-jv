var searchData=
[
  ['flotationforcegenerator_275',['FlotationForceGenerator',['../classFlotationForceGenerator.html#a1ecebdc58aff644d17e690910aa69cba',1,'FlotationForceGenerator::FlotationForceGenerator(Particle *particle, float maxDepth, float densityEnvironment, float heightEnvironment)'],['../classFlotationForceGenerator.html#a4859c0777b0c557933c44e1ad9e72947',1,'FlotationForceGenerator::FlotationForceGenerator(Particle *particle)']]]
];
